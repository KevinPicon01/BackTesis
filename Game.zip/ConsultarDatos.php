<?php

include "dbConnection.php";


$sql = "SELECT userName, derivadas,record_derivadas, funciones,record_funciones, limites, record_limites, ultima_conexion, recompensa FROM game.usuarios ";
$result = $pdo->query($sql);
$r = $result->fetchAll();

?>





<!DOCTYPE html>
<html>
<body>
<div style="">

</div>

<table border="1" cellpadding="5" cellspacing="0" style="margin: 6% auto auto;">
    <tr>
        <th>Nombre</th>
        <th>Derivadas</th>
        <th>Record Derivadas</th>
        <th>Limites</th>
        <th>Record Limites</th>
        <th>Funciones</th>
        <th>Record Funciones</th>
        <th>Ultima Conexion</th>
        <th>Ultima Recompensa</th>
    </tr>
    <?php foreach ($r as $v) { ?>
        <tr>
            <td><?= $v['userName'];  ?></td>
            <td><?= $v['derivadas'];  ?></td>
            <td><?= $v['record_derivadas'];  ?></td>
            <td><?= $v['limites'];  ?></td>
            <td><?= $v['record_limites'];  ?></td>
            <td><?= $v['funciones'];  ?></td>
            <td><?= $v['record_funciones'];  ?></td>
            <td><?= $v['ultima_conexion'];  ?></td>
            <td><?= $v['recompensa'];  ?></td>
        </tr>
    <?php } ?>
</table>

</body>

</html>